sap.ui.define(
    [
        "sap/ui/core/mvc/Controller"
    ],
    function(BaseController) {
      "use strict";
  
      return BaseController.extend("demoapp.controller.App", {
        onInit: function() {
        }
      });
    }
  );
  